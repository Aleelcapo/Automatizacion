#!/bin/bash
# Genera "salida/Puesto 5 (mapa).mp4" y sus subtítulos a partir de este paquete.
# La primera vez prepara el mapa (unos minutos y ~3 GB de disco); las siguientes lo reutiliza.
set -e
R="$(cd "$(dirname "$0")" && pwd)"
H="$R/herramientas"; D="$R/video"; OUT="$R/salida"; NAME="Puesto 5 (mapa)"
WORKERS="${WORKERS:-4}"
export GEO_LON0=-180 GEO_SPAN=660 WORK="$D" SRC_WORK="$R/recursos" LAYOUT=layout_cfg VIDEO_CFG="$D/video.json"
cd "$D"

# 1) mapa satelital reproyectado a Mercator y oscurecido (pirámide L0–L4)
if [ ! -f map/L4.png ]; then
  echo "== Preparando el mapa (solo la primera vez)"
  python3 "$H/prep_map.py" "$R/recursos/dl/map/bm7.jpg" "$R/recursos/dl/geo/ne_10m_admin_0_countries.shp" map
fi

# 2) fronteras, contornos y banderas recortadas de los seis países del recorrido
if [ ! -f assets/L4.npy ] || [ ! -f assets/flags.json ]; then
  echo "== Preparando fronteras y banderas"
  ONLY_COUNTRIES=KHM,NPL,ARM,SWE,SEN,KEN \
  COUNTRY_SHIFTS='{"KHM":0,"NPL":0,"ARM":0,"SWE":0,"SEN":0,"KEN":0}' \
    python3 "$H/build_assets.py" "$D"
fi

# 3) imagen, efectos de sonido y mezcla con la voz original
echo "== Renderizando cuadros"
python3 "$H/render.py" timings.json video.mp4 --workers "$WORKERS" 2>&1 | grep -v AVISO | tail -1
python3 "$H/sfx.py" timings.json sfx.wav
ffmpeg -v error -y -i raw.wav -af "highpass=f=60,loudnorm=I=-16:TP=-1.5:LRA=11" -ar 48000 voz_norm.wav
DUR=$(python3 -c "import json;print(json.load(open('timings.json'))['duration'])")
mkdir -p "$OUT"
echo "== Mezclando y exportando"
ffmpeg -v error -y -i video.mp4 -i voz_norm.wav -i sfx.wav -filter_complex "[1:a]aresample=48000,apad[v];[2:a]aresample=48000[s];[v][s]amix=inputs=2:duration=first:normalize=0,atrim=0:$DUR,alimiter=limit=0.89[a]" -map 0:v -map "[a]" -c:v libx264 -preset slow -crf 20 -pix_fmt yuv420p -c:a aac -b:a 192k -ac 2 -ar 48000 -movflags +faststart -shortest "$OUT/$NAME.mp4"
python3 "$H/make_srt.py" timings.json "$OUT/${NAME}_palabras.srt" "$OUT/${NAME}_frases.srt"
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate:format=duration -of compact "$OUT/$NAME.mp4"
echo "Listo: $OUT/$NAME.mp4"
