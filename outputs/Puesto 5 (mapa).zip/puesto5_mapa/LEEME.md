# Puesto 5 (mapa): cómo generar el video

Este paquete genera **`salida/Puesto 5 (mapa).mp4`**. Es el video vertical (1080×1920, 30 fps, unos 54 s) del puesto 10 de cada país según TasteAtlas. Recorre Camboya, Nepal, Armenia, Suecia, Senegal y Kenia.

También genera los subtítulos en dos versiones, palabra por palabra y por frases.

## Requisitos

- Python 3.10 o posterior.
- `ffmpeg` y `ffprobe` en el PATH, con libx264 y AAC.
- Unos 4 GB de disco libre y 8 GB de RAM para preparar el mapa la primera vez.

Instalá las dependencias de Python:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Ejecutar

```bash
bash generar.sh
```

El script hace tres pasos:

1. **Prepara el mapa** (solo la primera vez, varios minutos). Reproyecta la imagen satelital de la NASA a Mercator, le aplica el tono verde azulado oscuro y crea `video/map/`.
2. **Prepara fronteras y banderas** de los seis países (crea `video/assets/`).
3. **Renderiza el video.** Genera los cuadros y los efectos de sonido, mezcla todo con la voz original sin cambiarle velocidad ni tono y exporta a H.264 + AAC.

Al terminar quedan en `salida/` estos archivos:

- `Puesto 5 (mapa).mp4`
- `Puesto 5 (mapa)_palabras.srt`
- `Puesto 5 (mapa)_frases.srt`

Si tenés más o menos núcleos, cambiá cuántos procesos renderizan en paralelo: `WORKERS=8 bash generar.sh`.

Para rehacer el mapa o las banderas desde cero, borrá `video/map/` o `video/assets/` y volvé a ejecutar el script.

## Qué hay en el paquete

| Ruta | Contenido |
|---|---|
| `generar.sh` | Ejecuta todos los pasos |
| `herramientas/` | Código: mapa (`prep_map.py`, `geo.py`), banderas y fronteras (`build_assets.py`), render (`render.py`, `layout_cfg.py`), sonidos (`sfx.py`), subtítulos (`make_srt.py`) y alineación de la voz (`align.py`, opcional) |
| `video/raw.wav` | Voz original (extraída de `Voz_para_nicho_de_mapa_top_5_2.mov`) |
| `video/timings.json` | Momento de cada palabra en la voz (ya alineado) |
| `video/video.json` | Recorrido: países, platos, fotos y encuadre de cada foto |
| `video/guion.txt` | Guion |
| `video/photos/` | Fotos de Wikimedia Commons con licencia libre |
| `recursos/dl/map/bm7.jpg` | NASA Blue Marble, julio de 2004 (dominio público) |
| `recursos/dl/geo/` | Fronteras de Natural Earth 1:10m (dominio público) |
| `recursos/dl/flags/` | Banderas de Wikimedia Commons (dominio público) |
| `recursos/dl/font/` | Fuente Anton con su licencia SIL OFL 1.1 (`OFL.txt`) |
| `fuentes_y_licencias.md` | Autores y licencias de cada foto. Los créditos van fuera del video |

## Cambiar la voz o el guion (opcional)

`timings.json` ya viene calculado, así que no hace falta volver a alinear. Si cambiás la voz:

1. Instalá `faster-whisper`.
2. Convertí el audio a `video/raw.wav`.
3. Alinealo con el guion:

   ```bash
   cd video
   WHISPER_PROMPT="TasteAtlas, a-ping, thekua, chechil, toast skagen, thiebou yapp, mukimo." \
     python3 ../herramientas/align.py raw.wav guion.txt timings.json medium
   ```

4. Sumale 1,0 s al campo `duration` de `timings.json`; es la cola final del video.

La primera vez, `faster-whisper` descarga el modelo `medium`.

## Notas

- El paquete no incluye contraseñas, claves API ni archivos `.env`; el proceso no los necesita. Tampoco incluye el mapa ya procesado (unos 3 GB), porque `generar.sh` lo vuelve a crear, ni las dependencias de Python.
- Los puestos de TasteAtlas no se pudieron verificar automáticamente, porque el sitio bloquea las consultas. Conviene revisarlos antes de publicar (ver `fuentes_y_licencias.md`).
